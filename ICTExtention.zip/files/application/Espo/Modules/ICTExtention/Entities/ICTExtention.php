<?php

namespace Espo\Modules\ICTExtention\Entities;

class ICTExtention extends \Espo\Core\ORM\Entity
{
 /* public function __construct (  ) {
  //echo "heloo this is testing";

  
  }*/
}